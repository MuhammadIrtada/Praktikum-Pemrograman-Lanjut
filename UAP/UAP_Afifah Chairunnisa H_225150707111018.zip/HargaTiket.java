public interface HargaTiket {
    void detailPesanan(String nama);
}
